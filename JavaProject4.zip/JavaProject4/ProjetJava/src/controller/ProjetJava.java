/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import Model.Connect;
import View.Fenetre; 

import java.sql.SQLException;
import Model.Connexion; 
import Model.MenuD;
import View.AjoutEleve;
import View.Fenetre1;
import View.Menu;
import java.awt.Component;

/**
 *
 * @author Matthieu
 */
public class ProjetJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
           
        // TODO code application logic here
  
      
        MenuD m = new MenuD(); 
       m.Menu();
        
  
     
     
    }
    
}
