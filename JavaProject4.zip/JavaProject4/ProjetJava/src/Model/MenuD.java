/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.Fenetre1;
import java.util.Scanner;

/**
 *
 * @author HU
 */
public class MenuD {
    
    public void Menu()
    {
     Scanner saisie = new Scanner(System.in); 
        
        int  choix =0 ; 
        Connect c = new Connect(); 
          Fenetre1 f = new Fenetre1(); 
        while( choix != 3)
        {
    
        System.out.println(" --- Veuillez faire votre choix --- "); 
        System.out.println("1 : Mode Console  ");
        System.out.println("2 : Mode Graphique ");
     
        System.out.println("3: Quitter"); 
          
        choix = saisie.nextInt();
        if(choix == 1)
        {
        c.Connect();
        }
        if(choix == 2)
        {
                 
        f.setVisible(true); 
        
        }
        }
      //  System.out.println(choix);
     
        
        }

}
