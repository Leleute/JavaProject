/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Bulletin {
    public int id;
    public String appreciation;
    public int idtrimestre;
    public int idinscription;
    
    Bulletin(int idn,String apn,int idt,int idi)
    {
        id = idn; 
        appreciation = apn;
        idtrimestre = idt;
        idinscription = idi;  
    }
    
}
