/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Inscription {
    public int id;
    public int idclasse;
    public int ideleve;
    
    Inscription(int nid, int idc, int ide)
    {
        id = nid;
        idclasse = idc;
        ideleve = ide;
        
    }
    
    
}
