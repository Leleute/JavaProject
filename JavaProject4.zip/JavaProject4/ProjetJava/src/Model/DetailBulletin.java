/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
/**
 *
 * @author Matthieu
 */
public class DetailBulletin {
    public int id;
    public String appreciation;
    public int idbulletin;
    public int idenseignement;
    
    DetailBulletin(int nid, String app, int idb, int ide)
    {
        id = nid;
        appreciation = app;
        idbulletin = idb;
        idenseignement = ide;
    }
    
}
