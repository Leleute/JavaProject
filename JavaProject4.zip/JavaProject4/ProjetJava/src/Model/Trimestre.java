/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Trimestre {
    public int id;
    public int num;
    public String debut;
    public String fin;
    public int idannee;
    
    Trimestre(int nid, int nnum, String deb, String f, int ida)
    {
        id = nid;
        num = nnum;
        debut = deb;
        fin = f;
        idannee = ida;
    }
}
