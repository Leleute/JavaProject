/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Enseignement {
    public int id;
    public int idclasse;
    public int idpersonne;
    public int iddicipline;
    
    Enseignement(int nid, int idc, int idp, int idd)
    {
        id = nid;
        idclasse = idc;
        idpersonne = idp;
        iddicipline = idd;
    }
}
