/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Niveau {
    public int id;
    public String nom;
    
    Niveau(int nid, String nnom)
    {
        id = nid;
        nom = nnom;
    }
    
}
