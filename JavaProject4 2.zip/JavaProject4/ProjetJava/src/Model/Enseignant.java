/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Enseignant extends Personne{
    public int id;
    public String nom;
    public String prenom;
    
    Enseignant(int nid, String nnom, String nprenom)
    {
        id = nid;
        nom = nnom;
        prenom = nprenom;
    }
}
