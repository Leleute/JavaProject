/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import View.Fenetre1;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connect {
    
    private static HashMap<Integer, AnneeScolaire> AnneeScols = new HashMap<Integer, AnneeScolaire>();
    private static HashMap<Integer, Bulletin> Bults = new HashMap<Integer, Bulletin>();
    private static HashMap<Integer, Classe> Classes = new HashMap<Integer, Classe>();
    private static HashMap<Integer, DetailBulletin> DetailBulletins = new HashMap<Integer, DetailBulletin>();
    private static HashMap<Integer, Discipline> Disciplines = new HashMap<Integer, Discipline>();
    private static HashMap<Integer, Eleve> Eleves = new HashMap<Integer, Eleve>();
    private static HashMap<Integer, Ecole> Ecoles = new HashMap<Integer, Ecole>();
    private static HashMap<Integer, Enseignant> Enseignants = new HashMap<Integer, Enseignant>();
    private static HashMap<Integer, Evaluation> Evaluations  = new HashMap<Integer, Evaluation>();
    private static HashMap<Integer, Enseignement> Enseignements = new HashMap<Integer, Enseignement>();
    private static HashMap<Integer, Inscription> Inscriptions = new HashMap<Integer, Inscription>();
    private static HashMap<Integer, Niveau> Niveaux = new HashMap<Integer, Niveau>();
    private static HashMap<Integer, Trimestre> Trimestres = new HashMap<Integer, Trimestre>();
             
    public void Connect() {      
    try {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver O.K.");

      String url = "jdbc:mysql://localhost:8889/projectjava";
      String user = "root";
      String passwd = "root";
      
      Connection conn = DriverManager.getConnection(url, user, passwd);
      System.out.println("Connexion effective !");         
         
        try ( //Création d'un objet Statement
                Statement state = conn.createStatement()) {
            ChargementAnneeScol(state);
            ChargementBulletin(state);
            ChargementClasse(state);
            ChargementDetailBulletin(state);
            ChargementDiscipline(state);
            ChargementEcole(state);
            ChargementEnseignement(state);
            ChargementEvaluation(state);
            ChargementInscription(state);
            ChargementNiveau(state);
            ChargementTrimestre(state);
            ChargementPersonnes(state);
            //L'objet ResultSet contient le résultat de la requête SQL
            System.out.println(Eleves.size());
            Menu(state);
            state.close();
            conn.close();
        }
      
      
      
    } catch (ClassNotFoundException | SQLException e) {
    }      
  }
    
    
    
    public void ConnectG()
    {
        
    try  {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver O.K.");

      String url = "jdbc:mysql://localhost:8889/projectjava";
      String user = "root";
      String passwd = "root";
      
      Connection conn = DriverManager.getConnection(url, user, passwd);
      System.out.println("Connexion effective !");         
         
        try ( //Création d'un objet Statement
                Statement state = conn.createStatement()) {
            ChargementAnneeScol(state);
            ChargementBulletin(state);
            ChargementClasse(state);
            ChargementDetailBulletin(state);
            ChargementDiscipline(state);
            ChargementEcole(state);
            ChargementEnseignement(state);
            ChargementEvaluation(state);
            ChargementInscription(state);
            ChargementNiveau(state);
            ChargementTrimestre(state);
            ChargementPersonnes(state);
            //L'objet ResultSet contient le résultat de la requête SQL
           // System.out.println(Eleves.size());
           // Menu(state);
            state.close();
            conn.close();
        }
      
      
      
    } 
    catch (ClassNotFoundException | SQLException e) {
    } 
    }
    
    
     public static void Menu(Statement state)
    {
        int a=20;
        Fenetre1 f = new Fenetre1(); 
        while(a!=0)
        {
        Scanner saisi = new Scanner((System.in));
        System.out.println("Vos choix : ");
        System.out.println("0 : Quitter");
        System.out.println("1 : Affichez les eleves ");
        System.out.println("2 : Affichez les professeurs");
        System.out.println("3 : Ajouter un eleve");
        System.out.println("4 : Ajouter un professeur");
        System.out.println("5 : Supprimer un eleve");
        System.out.println("6 : Supprimer un professeur");
        System.out.println("7 : Ajout d'une note");
        System.out.println("8 : Modifier une classe");
        System.out.println("9 : Voir une classe");
        System.out.println("10: Mode graphique "); 
        a = saisi.nextInt();
        if(a == 1)AfficherEleves();
        if(a == 2)AfficherProf();
        if(a == 3)AjouterPersonne(state, 1);
        if(a == 4)AjouterPersonne(state, 2);
        if(a == 5)SupprimerPersonne(state, 1);
        if(a == 6)SupprimerPersonne(state, 2);
        if(a == 7)AjoutNote(state);
        if(a == 8)ModifierClasse(state);
        if(a == 9)AfficherElevesClasse(state);
        if( a == 10) f.setVisible(true); 
        } 
        
    }
    
      public static void AfficherElevesClasse(Statement state)
    {
        Scanner saisi = new Scanner(System.in);
        System.out.println("Veuillez rentrer l'id de la classe dont vous voulez voir les eleves : ");
        for(HashMap.Entry<Integer, Classe> entry : Classes.entrySet()){
            int cle = entry.getKey();
            Classe value = entry.getValue();
            System.out.println(cle + " " + value.nom + " " + Ecoles.get(value.idecole).nom);
        }
     
     int idc = saisi.nextInt();
     for(HashMap.Entry<Integer, Inscription> entry : Inscriptions.entrySet()) {
        int cle = entry.getKey();
        Inscription valeur = entry.getValue();
        // traitements
        if(idc == valeur.idclasse)
        {
            System.out.println(cle + " " + Eleves.get(valeur.ideleve).nom + " " + Eleves.get(valeur.ideleve).prenom);
        }
    }
     
         
    }
    
       public static void ModifierClasse(Statement state)
    {
        Scanner saisi = new Scanner(System.in);
        AfficherEleves();
        System.out.println("Veuillez rentrer l'id de l'éléve a changer de classe");
        int ide = saisi.nextInt();
        for(HashMap.Entry<Integer, Classe> entry : Classes.entrySet()){
            int cle = entry.getKey();
            Classe value = entry.getValue();
            System.out.println(cle + " " + value.nom + " " + Ecoles.get(value.idecole).nom);
        }
        System.out.println("Veuillez rentrer l'id de la nouvelle classe");
        int idc = saisi.nextInt();
        
        try{
            int result = state.executeUpdate("UPDATE inscription SET idclasse = '"+idc+"'  WHERE IDeleve = '"+ide+"'");
            if (result != 0)
            {
                System.out.println("8Modification Classe reussit");
                ChargementInscription(state);

                  
            }
            }
                catch (SQLException e) {
                }
        
        
        
    }
       
       
    public static void AjoutNote(Statement state)
    {
        String app = "";
        int idprof;
        int ideleve;
        int idbult = 0;
        int idenseign = 0;
        int idinscri = 0;
        int dbexiste = 0;
        int iddet = 0;
        Scanner saisie = new Scanner(System.in);
        for(HashMap.Entry<Integer, Enseignant> entry : Enseignants.entrySet()) {
        int cle = entry.getKey();
        Enseignant valeur = entry.getValue();
        // traitements
        System.out.println(cle + " " + valeur.nom + " " + valeur.prenom);
        }
        System.out.println("Veuillez rentrer l'id du prof voulant ajouter une note");
        idprof = saisie.nextInt();
        for(HashMap.Entry<Integer, Eleve> entry : Eleves.entrySet()) {
        int cle = entry.getKey();
        Eleve valeur = entry.getValue();
        // traitements
        System.out.println(cle + " " + valeur.nom + " " + valeur.prenom);
        }
        System.out.println("Veuliiez rentrer l'id de l'eleve a qui vous voulez ajouter une note");
        ideleve = saisie.nextInt();
        for(HashMap.Entry<Integer, Inscription> entry : Inscriptions.entrySet()){
            int cle = entry.getKey();
            Inscription value = entry.getValue();
            if(value.ideleve == ideleve)
            {
                idinscri = cle;
            }
        }
        for(HashMap.Entry<Integer, Bulletin> entry : Bults.entrySet()){
            int cle = entry.getKey();
            Bulletin value = entry.getValue();
            if(value.idinscription == idinscri)
            {
                idbult = cle;
            }
        }
        for(HashMap.Entry<Integer, Enseignement> entry : Enseignements.entrySet()){
            int cle = entry.getKey();
            Enseignement value = entry.getValue();
            if(value.idpersonne == idprof)
            {
                idenseign = cle;
            }
        }
        
           
        for(HashMap.Entry<Integer, DetailBulletin> entry : DetailBulletins.entrySet())
        {
            int cle = entry.getKey();
            DetailBulletin valeur = entry.getValue();
            if(valeur.idbulletin == idbult)
            {
                dbexiste = 1;
                iddet = cle;
            } 
        }
        if(dbexiste == 0){
        try{
            int result = state.executeUpdate("INSERT INTO detailbulletin(ID, appreciation, IDbulletin, IDenseignement) VALUES (NULL, '"+app+"', '"+idbult+"', '"+idenseign+"')");
            if (result != 0)
            {
                System.out.println("Creation detail bulletin1 reussit");
                ChargementDetailBulletin(state);
                        
            }
            }
                catch (SQLException e) {
                }
        }
        System.out.println(idprof + " "+ ideleve + " " + idbult + " " + idenseign + " " + idinscri + " " + dbexiste);
        
        System.out.println("Veuillez rentrer la note a mettre");
        int note = saisie.nextInt();
        System.out.println("Veuillez rentrer l'appreciation");
        app = saisie.next();
        try{
            int result = state.executeUpdate("INSERT INTO evaluation(ID, note, appreciation, IDdetailbulletin) VALUES (NULL, '"+note+"', '"+app+"', '"+iddet+"')");
            if (result != 0)
            {
                System.out.println("Creation Evalutation reussit");
                ChargementDetailBulletin(state);
                        
            }
        }
            catch (SQLException e) {
        }
    }
    
    public static void SupprimerPersonne(Statement state, int type)
    {
        Scanner saisi = new Scanner((System.in));
        int id;
        if(type == 1)AfficherEleves();
        if(type == 2)AfficherProf();
        System.out.println("Veulliez rentrer l'id de la personne que vous voulez supprimer");
        id = saisi.nextInt();
        try{
        
        int result = state.executeUpdate("DELETE FROM personne WHERE ID LIKE "+id+"");
        if(result != 0)
        {
            System.out.println("Reussite");    
            ChargementPersonnes(state);
        }
        }
        catch (SQLException e) {
        }
        if(type == 1)
        {
        try{
            int result = state.executeUpdate("DELETE FROM inscription WHERE IDeleve LIKE "+id+"");
        if(result != 0)
        {
            System.out.println("Reussite suppression inscription");    
            ChargementPersonnes(state);
        }
        }
        catch (SQLException e) {
        }
        }
        if(type == 2)
        {
            try{
            int result = state.executeUpdate("DELETE FROM enseignement WHERE IDpersonne LIKE "+id+"");
        if(result != 0)
        {
            System.out.println("Reussite suppression Enseignement");    
            ChargementPersonnes(state);
        }
        }
        catch (SQLException e) {
        }
        }
    }
    
    public static void AfficherEleves()
    {
    for(HashMap.Entry<Integer, Eleve> entry : Eleves.entrySet()) {
        int cle = entry.getKey();
        Eleve valeur = entry.getValue();
        // traitements
        System.out.println(cle + " " + valeur.nom + " " + valeur.prenom);
        }
    }
    
    public static void AfficherProf()
    {
        for(HashMap.Entry<Integer, Enseignant> entry : Enseignants.entrySet()) {
        int cle = entry.getKey();
        Enseignant valeur = entry.getValue();
        // traitements
        System.out.println(cle + " " + valeur.nom + " " + valeur.prenom);
        }
        
    }
    
    public static void AjouterPersonne(Statement state, int type)
    {
        
        Scanner saisi = new Scanner((System.in));
        String nom;
        String prenom;
        System.out.println("Rentrer le nom");
        nom = saisi.next();
        System.out.println("Rentrer le prenom");
        prenom = saisi.next();
        try{
        
        int result = state.executeUpdate("INSERT INTO personne(ID, nom, prenom, soustable) VALUES (NULL, '"+nom+"', '"+prenom+"', '"+type+"')");
        if(result != 0)
        {
            if(type == 1)
            {
                ChargementPersonnes(state);
                int ide = 0;
                for(HashMap.Entry<Integer, Eleve> entry : Eleves.entrySet()) {
                    Eleve valeur = entry.getValue();
                    if(valeur.nom.equals(nom) && valeur.prenom.equals(prenom))
                    {
                        ide = valeur.id;
                    }   
                }
                System.out.println("Veuillez rentrer l'idée de la classe dans laquelle vous voulez incrire l'eleve :");
                for(HashMap.Entry<Integer, Classe> entry : Classes.entrySet()) {
                    int cle = entry.getKey();
                    Classe valeur = entry.getValue();
                    // traitements
                    System.out.println(cle + " " + AnneeScols.get(valeur.idannee).id + " " + valeur.nom + " " + Ecoles.get(valeur.idecole).nom+ " " + Niveaux.get(valeur.idniveau).nom);
                }
                
                int idclasse = saisi.nextInt();
                int result2;
                result2 = 0;
                try{
                result2 = state.executeUpdate("INSERT INTO inscription(ID, IDclasse, IDeleve) VALUES (NULL, '"+idclasse+"', '"+ide+"')");
                if (result2 != 0)
                {
                    System.out.println("Inscription reussitt");
                }
                }
                catch (SQLException e) {
                } 
                }                
            }
            if(type == 2)
            {
                ChargementPersonnes(state);
                int idp= 0;
                int idd;
                int idc;
                for(HashMap.Entry<Integer, Enseignant> entry : Enseignants.entrySet()) {
                    Enseignant valeur = entry.getValue();
                    if(valeur.nom.equals(nom) && valeur.prenom.equals(prenom)) 
                    {
                        idp = valeur.id;
                    }   
                }
                System.out.println("Veulliez rentrer l'id de la matiere que vous voulez enseigner");
                for(HashMap.Entry<Integer, Discipline> entry : Disciplines.entrySet()){
                    int cle = entry.getKey();
                    Discipline valeur = entry.getValue();
                    System.out.println(cle + " " + valeur.nom);
                }
                idd = saisi.nextInt();
                System.out.println("Veuiller rentrer l'id de la classe a laquelle vous voulez enseigner");
                for(HashMap.Entry<Integer, Classe> entry : Classes.entrySet()) {
                    int cle = entry.getKey();
                    Classe valeur = entry.getValue();
                    // traitements
                    System.out.println(cle + " " + AnneeScols.get(valeur.idannee).id + " " + valeur.nom + " " + Ecoles.get(valeur.idecole).nom+ " " + Niveaux.get(valeur.idniveau).nom);
                }
                idc = saisi.nextInt();
                int result2;
                result2 = 0;
                try{
                result2 = state.executeUpdate("INSERT INTO enseignement(ID, IDclasse, IDpersonne, IDdiscipline) VALUES (NULL, '"+idc+"', '"+idp+"', '"+idd+"')");
                if (result2 != 0)
                {
                    System.out.println("Inscription reussitt");
                }
                }
                catch (SQLException e) {
                } 
                
                
            }
        }        
        catch (SQLException e) {
        }           
    }
    
    
  public static void ChargementAnneeScol(Statement state)
  {
      AnneeScols.clear();
      
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM anneeScolaire")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                  }
                  AnneeScols.put(id, new AnneeScolaire(id));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }     
      
  }
  
  public static void ChargementBulletin(Statement state)
  {
      Bults.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM bulletin")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String app = "";
                  int idtrim = 0;
                  int idins = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      
                      if(i == 2)
                          app = result.getObject(i).toString();
                      if(i == 3)
                          idtrim = Integer.parseInt(result.getObject(i).toString());
                      if(i == 4)
                          idins = Integer.parseInt(result.getObject(i).toString());
                  }
                  Bults.put(id, new Bulletin(id, app, idtrim, idins));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }     
      
  }
  
  public static void ChargementClasse(Statement state)
  {
      Classes.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM classe")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String nom = "";
                  int ida = 0;
                  int ide = 0;
                  int idn = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          nom = result.getObject(i).toString();
                      if(i == 3)
                          ida = Integer.parseInt(result.getObject(i).toString());
                      if(i == 4)
                          ide = Integer.parseInt(result.getObject(i).toString());
                      if(i == 5)
                          idn = Integer.parseInt(result.getObject(i).toString());
                  }
                  Classes.put(id, new Classe(id, nom, ida, ide, idn));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }     
      
  }
  
  public static void ChargementDetailBulletin(Statement state)
  {
      DetailBulletins.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM detailbulletin")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String app = "";
                  int idb = 0;
                  int ide = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          app = result.getObject(i).toString();
                      if(i == 3)
                          idb = Integer.parseInt(result.getObject(i).toString());
                      if(i == 4)
                          ide = Integer.parseInt(result.getObject(i).toString());
                  }
                  DetailBulletins.put(id, new DetailBulletin(id, app, idb, ide));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }    
  }
  
  public static void ChargementDiscipline(Statement state)
  {
      Disciplines.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM discipline")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String nom = "";
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          nom = result.getObject(i).toString();
                  }
                  Disciplines.put(id, new Discipline(id, nom));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }  
  }
  public static void ChargementEcole(Statement state)
  {
      Ecoles.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM ecole")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String nom = "";
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          nom = result.getObject(i).toString();
                  }
                  Ecoles.put(id, new Ecole(id, nom));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }    
  }
  
  public static void ChargementEnseignement(Statement state)
  {
      Enseignements.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM enseignement")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  int idc = 0;
                  int idp = 0;
                  int idd = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          idc = Integer.parseInt(result.getObject(i).toString());
                      if(i == 3)
                          idp = Integer.parseInt(result.getObject(i).toString());
                      if(i == 4)
                          idd = Integer.parseInt(result.getObject(i).toString());
                  }
                  Enseignements.put(id, new Enseignement(id, idc, idp, idd));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }     
  }
  public static void ChargementEvaluation(Statement state)
  {
      Evaluations.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM evaluation")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  int note = 0;
                  String app = "";
                  int idd = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          note = Integer.parseInt(result.getObject(i).toString());
                      if(i == 3)
                          app = result.getObject(i).toString();
                      if(i == 4)
                          idd = Integer.parseInt(result.getObject(i).toString());
                  }
                  Evaluations.put(id, new Evaluation(id, note, app, idd));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    } 
    
  }
  
  public static void ChargementInscription(Statement state)
  {
      Inscriptions.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM inscription")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  int idc = 0;
                  int ide = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          idc = Integer.parseInt(result.getObject(i).toString());
                      if(i == 3)
                          ide = Integer.parseInt(result.getObject(i).toString());
                  }
                  Inscriptions.put(id, new Inscription(id, idc, ide));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    } 
    
  }
  public static void ChargementNiveau(Statement state)
  {
      Niveaux.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM niveau")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String nom = "";
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          nom = result.getObject(i).toString();
                  }
                  Niveaux.put(id, new Niveau(id, nom));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    } 
    
  }
  
  public static void ChargementTrimestre(Statement state)
  {
      Trimestres.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM trimestre")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  int num = 0;
                  String deb = "";
                  String fin= "";
                  int ida = 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          num = Integer.parseInt(result.getObject(i).toString());
                      if(i == 3)
                          deb = result.getObject(i).toString();
                      if(i == 4)
                          fin = result.getObject(i).toString();
                      if(i == 5)
                          ida = Integer.parseInt(result.getObject(i).toString());
                  }
                  Trimestres.put(id, new Trimestre(id, num, deb, fin, ida));
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }    
  }
  
  public static void ChargementPersonnes(Statement state)
  {
      Eleves.clear();
      Enseignants.clear();
      try{
          //On récupère les MetaData
          try (ResultSet result = state.executeQuery("SELECT * FROM personne")) {
              //On récupère les MetaData
              ResultSetMetaData resultMeta = result.getMetaData();
              while(result.next()){
                  int id = 0;
                  String nom = "";
                  String prenom= "";
                  int type= 0;
                  for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                  {
                      if(i == 1)
                          id = Integer.parseInt(result.getObject(i).toString());
                      if(i == 2)
                          nom = result.getObject(i).toString();
                      if(i == 3)
                          prenom = result.getObject(i).toString();
                      if(i == 4)
                          type = Integer.parseInt(result.getObject(i).toString());
                  }
                  
                  if(type == 1)
                  {
                      Eleves.put(id, new Eleve(id, nom, prenom));
                  }
                  if(type == 2)
                      Enseignants.put(id, new Enseignant(id, nom, prenom));
                  
              }   }
      }
      catch (NumberFormatException | SQLException e) {
    }    
  }
  
}



