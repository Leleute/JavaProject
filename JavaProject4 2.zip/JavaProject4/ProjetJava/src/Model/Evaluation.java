/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Evaluation {
    public int id;
    public int note;
    public String appreciation;
    public int iddetailbult;
    
    Evaluation(int nid, int nnote, String app, int idd)
    {
        id = nid;
        note = nnote;
        appreciation = app;
        iddetailbult = idd;
    }
    
}
