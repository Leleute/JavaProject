/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Matthieu
 */
public class Classe {
    public int id;
    public String nom;
    public int idannee;
    public int idecole;
    public int idniveau;
    
    Classe(int nid,String n, int ina, int ide, int idn)
    {
        id = nid;
        nom = n;
        idannee = ina;
        idecole = ide;
        idniveau = idn;
    }        
    
}
